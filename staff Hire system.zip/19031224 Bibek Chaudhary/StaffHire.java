
public class StaffHire
{
   protected int vacancyNumber;
   protected String designation;
   protected String jobType;
   
   public StaffHire(int vacancyNumber, String designation, String jobType) //contructing objects of class staffHire
   {
       this.vacancyNumber=vacancyNumber; //initializing instance variable
       this.designation=designation;
       this.jobType=jobType;
   }
   public void setvacancyNumber(int vacancyNumber)//setter method
   {
       this.vacancyNumber=vacancyNumber;
   }
   public int getvacancyNumber()//getter method
   {
       return this.vacancyNumber;
   }
   public void setdesignation(String designation) 
   {
       this.designation=designation;
   }
   public String getdesignation()
   {
       return this.designation;
   }
   public void setjobType(String jobType)
   {
       this.jobType=jobType;
   }
   public String getjobType()
   {
       return this.jobType;
   }
   public void display()
   {
       System.out.println("vacancyNumber.."+getvacancyNumber());
       System.out.println("designation..."+getdesignation());
       System.out.println("jobType..."+getjobType());
   }
}

