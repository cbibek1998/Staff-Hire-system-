
public class FullTimeStaffHire extends StaffHire
{
   private int salary;
   private int workingHour;
   private String staffName;
   private String joiningDate;
   private String qualification;
   private String appointedBy;
   private boolean joined;
   
   public FullTimeStaffHire(int vacancyNumber, String designation, String jobType, int salary, int workingHour)//contructing objects of class FullTimeStaffHire
   {
       super(vacancyNumber, designation, jobType); //calling the object of class StaffHire
       this.salary=salary;
       this.workingHour=workingHour;
       this.staffName="";
       this.joiningDate="";
       this.qualification="";
       this.appointedBy="";
       this.joined=false;
   }
   public int getsalary()//getter method
   {
       return this.salary;
   }
   public void setworkingHour(int workingHour)//setter method
   {
       this.workingHour=workingHour;
   }
   public int getworkingHour()
   {
       return this.workingHour;
   }
   public void setstaffName(String staffName)
   {
       this.staffName=staffName;
   }
   public String getstaffName()
   {
       return this.staffName;
   }
   public void joiningDate(String joiningDate)
   {
       this.joiningDate=joiningDate;
   }
   public String getjoiningDate()
   {
       return this.joiningDate;
   }
   public void setappointedBy(String appointedBy)
   {
       this.appointedBy=appointedBy;
   }
   public String getappointedBy()
   {
       return this.appointedBy;
   }
   public void setqualification(String qualification)
   {
       this.qualification=qualification;
   }
   public String getqualification()
   {
       return this.qualification;
   }
   public void setjoined(boolean joined)
   {
       this.joined=joined;
   }
   public boolean getjoined()
   {
       return this.joined;
   }
   public void setsalary(int salary)
   {
       if (this.joined==true) 
       {
           System.out.println("The salary cannot be changed");
       }
       else
       {
           this.salary=salary;
       }
   }
   public void appointFullTimeStaffhire(String staffName, String joiningDate, String qualification, String appointedBy)
   {
       if(joined==false)
       {
         System.out.println("staff is already appointed");
         System.out.println("staffName..."+getstaffName());
         System.out.println("joiningDate..."+getjoiningDate());
         System.out.println("qualification..."+getqualification());
         System.out.println("appointedBy..."+getappointedBy());
       }
       else
       {
           this.staffName=staffName;
           this.joiningDate=joiningDate;
           this.qualification=qualification;
           this.appointedBy=appointedBy;
           this.joined=joined;
       }
   }
   public void display()
   {
       super.display();
       if(this.joined==true) 
       {
           System.out.println("staffName..."+getstaffName());
           System.out.println("salary..."+getsalary());
           System.out.println("workingHour..."+getworkingHour());
           System.out.println("joiningDate..."+getjoiningDate());
           System.out.println("qualification..."+getqualification());
           System.out.println("appointedBy..."+getappointedBy());
           
       }
   }
  
}
