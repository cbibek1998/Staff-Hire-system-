
public class PartTimeStaffHire extends StaffHire
{
   private int workingHour;
   private int wagesPerHour;
   private String staffName;
   private String joiningDate;
   private String qualification;
   private String appointedBy;
   private String shifts;
   private boolean joined;
   private boolean terminated;
   
   public PartTimeStaffHire(int vacancyNumber, String designation, String jobType, int wagesPerHour, String shifts)//constructing object of class FullTimeStaffHire
   {
       super(vacancyNumber, designation, jobType);//calling the objects of class staffHire
       this.workingHour=workingHour;//initializing instance variables
       this.wagesPerHour=wagesPerHour;
       this.shifts=shifts;
       this.staffName="";
       this.joiningDate="";
       this.qualification="";
       this.appointedBy="";
       this.joined=false;
       this.terminated=false;
   }
   public void setworkingHour(int workingHour)
   {
       this.workingHour=workingHour;
   }
   public int getworkingHour()
   {
       return this.workingHour;
   }
   public void setwagesPerHour(int wagesPerHour)
   {
       this.wagesPerHour=wagesPerHour;
   }
   public int getwagesPerHour()
   {
       return this.wagesPerHour;
   }
   public String getshifts()
   {
       return this.shifts;
   }
   public void setstaffName(String staffName)
   {
       this.staffName=staffName;
   }
   public String getstaffName()
   {
       return this.staffName;
   }
   public void setjoiningDate(String joiningDate)
   {
       this.joiningDate=joiningDate;
   }
   public String getjoiningDate()
   {
       return this.joiningDate;
   }
   public void setqualification(String qualification)
   {
       this.qualification=qualification;
   }
   public String getqualification()
   {
       return this.qualification;
   }
   public void setappointedBy(String appointedBy)
   {
       this.appointedBy=appointedBy;
   }
   public String getappointedBy()
   {
       return this.appointedBy;
   }
   public void setjoined(boolean joined)
   {
       this.joined=joined;
   }
   public boolean getjoined()
   {
       return this.joined;
   }
   public void setterminated(boolean terminated)
   {
       this.terminated=terminated;
   }
   public boolean getterminated()
   {
       return this.terminated;
   }
   public void setshifts(String shifts)
   {
       if(this.joined==true)
       {
           System.out.println("working shift cannot be changed");
       }
       else 
       {
           this.shifts=shifts;
       }
   }
   public void appointPartTimeStaffhire(String staffName, String joiningDate, String qualification, String appointedBy)
   {
       if(joined == false)
       {
           System.out.println("staff is already appointed");
           System.out.println("staffName..."+getstaffName());
           System.out.println("joiningDate..."+getjoiningDate());
       }
       else 
       {
           this.staffName=staffName;
           this.joiningDate=joiningDate;
           this.qualification=qualification;
           this.appointedBy=appointedBy;
           this.joined=true;
           this.terminated=false;
       }
   }
   public void terminated()
   {
       if(terminated==false)
       {
           this.staffName="";
           this.joiningDate="";
           this.qualification="";
           this.joined=false;
           this.terminated=true;
       }
       else
       {
           System.out.println("staff is already terminated");
       }
    }
    public void display()
    {
        super.display();
        if(joined==true)
        {
            System.out.println("staffName..."+getstaffName());
            System.out.println("wagesPerHour..."+getwagesPerHour());
            System.out.println("joiningDate..."+getjoiningDate());
            System.out.println("qualification..."+getqualification());
            System.out.println("appointedBy..."+getappointedBy());
            int incomePerDay=getwagesPerHour() +getworkingHour();
            System.out.println("incomePerDay..."+incomePerDay);      
        }
        else
        {
            System.out.println("No staff data");
        }
    }
}
